
public interface Area {
	/**
	 * All class that implement this class must implement this method
	 * @return the area based on the formula written for the specific class
	 */
	double getArea();
}
